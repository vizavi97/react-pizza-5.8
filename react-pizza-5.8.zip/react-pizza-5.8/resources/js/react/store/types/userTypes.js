export const ME_QUERY = "ME_QUERY"
export const USER_LOGIN = "USER_LOGIN"
export const USER_REGISTER = "USER_REGISTER"
export const USER_LOGOUT = "USER_LOGOUT"
