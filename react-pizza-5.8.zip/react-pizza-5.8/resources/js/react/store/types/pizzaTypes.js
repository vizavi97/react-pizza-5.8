export const GET_ALL_PIZZAS = 'GET_ALL_PIZZAS';
